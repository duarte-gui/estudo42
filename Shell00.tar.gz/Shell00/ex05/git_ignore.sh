cat .gitignore #se voce nao tem um desses, tá commitando senha pra geral

#eu sei que a norminette não passa, mas assim eu acho a melhor forma pra não enviar "coisinhas", 
#porém funciona "pro enunciado"