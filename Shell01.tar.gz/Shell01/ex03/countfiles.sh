#!/bin/sh

# o link não é arquivo regular

find . -type f,d | wc -l