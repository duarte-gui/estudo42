#!/bin/sh
####Eu acho que entendi o enunciado errado, 

ls  -l | sed -n "p;n" 